<?php

define("IKEY", md5(""));
define("SKEY", md5(""));
define("CKEY", sha1(""));
define("VKEY", sha1(""));


?>
