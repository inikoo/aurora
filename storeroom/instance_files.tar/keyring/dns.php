<?php
$dns_pwd="";
$dns_db="";
$dns_user="";
$dns_host="";
$memcache_ip="";

?>
